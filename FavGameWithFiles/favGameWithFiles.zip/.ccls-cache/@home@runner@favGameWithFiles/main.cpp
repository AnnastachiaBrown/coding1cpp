#include "includes.h"

int main() {
  cout << "Howdy partner! Let's make a list of yer favorite games!\n";

    //all the variables and jazz!!!
    ofstream gameFile;
    string numInput;
    string line;
    vector <string> favGames;
    string gameInput;  
    
    
    while (true){
        cout << "What would you like to do?\n";
        cout << "press 1 to add a game to the list!\n";
        cout << "press 2 to see the list!\n";
        cout << "press 3 to save and quit!\n";

        getline(cin, numInput);

        if(numInput == "1"){    //we adding a game
            cout << "What game should be added to the list";
            getline(cin, gameInput);
            favGames.push_back(gameInput);
            cout << "cool game partner";
        }//end of if
        // else if(numInput == "2"){// we looking at the games
        //     cout << "here is your list of games"; 
        //     gameFile.open("gameFavs.txt");//making and opening the file
           
        //     while(getline(gameFile, line)){  //getline notWorking IDK why 
            //     cout << line << "\n";  
            //     favGames.push_back(line);
            // }
        // }//end of else if
        else if(numInput == "3"){//we ending this thing
            cout << "thanks for adding to my list. I'll save it for you\n";
            cout<< "Saving ...\n";
            cout << "Saved!\n";
            cout << "See you again partner!";
            break; // ends the game
        }//end of else if 
        else{
            cout << " make sure you typed that correctly! try again partner!";
        }
    }//end of big while loop
    
}//end of int main