#include "includes.h"



int main() {
    cout << "Howdy Partner! Let's make a list of your favorite games!\n";

    vector <string> favGames;
    string line;
    string input; 
    ofstream gameFile; 
    string gameInput = "";
    
    while(true){
            cout << "what would you like to do?\n";
            cout << "Press 1 to add to the list.\n";
            cout << "Press 2 to see the list.\n";
            cout << "Press 3 to quit.\n";

            getline(cin, input);   
            
            if(input == "1"){//add to the list
                getline(cin, gameInput);
                favGames.push_back(gameInput);
            }//end of if statement (1)
           
            else if(input == "2"){//see the list
                gameFile.open("gameList.txt"); //opening the specific file
               if(gameFile.is_open()){
                while(getline(gameFile, line)){

                    cout << line << "\n";  
                    favGames.push_back(line);
                }//end of while 
               }//end of if
                gameFile.close();//close the game list file 
            }//end of else if(2)
            
            else if(input =="3"){//quit out
                
            }//end of else loop(3)
            else{
                cout << "make sure your answer is a just a 1,2, or 3";
            }
    }//end of while loop
    gameFile.open("gameList.txt"); //opening the specific file
    
    gameFile.close();//close the game list file 

    
}//end of int main